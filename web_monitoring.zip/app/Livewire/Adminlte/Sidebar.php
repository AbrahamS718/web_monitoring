<?php

namespace App\Livewire\Adminlte;

use Livewire\Component;

class Sidebar extends Component
{
    public function render()
    {
        return view('livewire.adminlte.sidebar');
    }
}
